// Copyright 2014 Isis Innovation Limited and the authors of InfiniTAM
#ifdef COMPILE_WITH_METAL

#include "ITMSwappingEngine_Metal.h"

//using namespace ITMLib::Engine;
//
//template<class TVoxel>
//ITMSwappingEngine_Metal<TVoxel,ITMVoxelBlockHash>::ITMSwappingEngine_Metal(void)
//{
//}
//
//template<class TVoxel>
//ITMSwappingEngine_Metal<TVoxel,ITMVoxelBlockHash>::~ITMSwappingEngine_Metal(void)
//{
//}
//
//template<class TVoxel>
//int ITMSwappingEngine_Metal<TVoxel,ITMVoxelBlockHash>::DownloadFromGlobalMemory(ITMScene<TVoxel,ITMVoxelBlockHash> *scene, ITMView *view)
//{
//	return 0;
//}
//
//template<class TVoxel>
//void ITMSwappingEngine_Metal<TVoxel,ITMVoxelBlockHash>::IntegrateGlobalIntoLocal(ITMScene<TVoxel,ITMVoxelBlockHash> *scene, ITMView *view)
//{
//
//}
//
//template<class TVoxel>
//void ITMSwappingEngine_Metal<TVoxel,ITMVoxelBlockHash>::SaveToGlobalMemory(ITMScene<TVoxel,ITMVoxelBlockHash> *scene, ITMView *view)
//{
//
//}
//
//template class ITMLib::Engine::ITMSwappingEngine_Metal<ITMVoxel, ITMVoxelIndex>;

#endif