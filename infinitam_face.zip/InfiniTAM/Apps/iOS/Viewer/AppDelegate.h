//
//  AppDelegate.h
//  InfiniTAM-Metal
//
//  Created by Victor Adrian Prisacariu on 08/11/2014.
//  Copyright (c) 2014 Victor Adrian Prisacariu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end